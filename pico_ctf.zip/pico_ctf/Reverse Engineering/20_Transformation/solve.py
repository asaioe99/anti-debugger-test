
f = open('enc', 'r', encoding='UTF-8')
data = f.read()

flag = ''

for i in range(0, len(data), 1):
    flag = flag + chr((ord(data[i]) & 0xff00) >> 8)
    flag = flag + chr((ord(data[i]) & 0x00ff))
    
print(flag)


f.close()
